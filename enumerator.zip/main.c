/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

void main ()
{
    enum month{Jan, Feb, March, April, May, June, July, Aug, Sept, Oct, Nov, Dec};
  printf ("Jan=%d\n",Jan);
  printf ("Feb%d\n",Feb);
  printf ("March%d\n",March);
  printf ("May=%d\n",May);
  printf ("June=%d\n",June);
//   printf (Jan=%d\n",Jan);
//   printf (Jan=%d\n",Jan);
//   printf (Jan=%d\n",Jan);
//   printf (Jan=%d\n",Jan);
//   printf (Jan=%d\n",Jan);
//   printf (Jan=%d\n",Jan);
//   printf (Jan=%d\n",Jan);

  return ;
}
