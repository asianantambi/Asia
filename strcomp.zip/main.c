/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void main()
{
    int number;
    char name[10];
    char name2[15];
    char name3[20];
    printf("name2: ");
    gets(name2);
    printf("name3:");
    gets(name3);
    strcomp(name2, name3);
    printf("%d",number);

    return ;
}
